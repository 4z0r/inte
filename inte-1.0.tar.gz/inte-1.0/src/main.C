#include <stdio.h>
#include <stdlib.h>
#include "main.H"
#include "debug.H"
#include "functions.H"

int main(int argc, char *argv[], char *envp[])
{
  printf("all set up.\n");
  return(EXIT_SUCCESS);
}
